package web;
//Module 파트 Class로 만듬
public class lottomodel {
	//this 뭐뭐 써봤닝
	int sum = 0; // 필드에 선언하면 아해 this를 쓸 수 있다.
	public String lottotest(int aa, int bb, int cc, int dd, int ee, int ff) {
		// TODO Auto-generated method stub
		return null;
	}


}
